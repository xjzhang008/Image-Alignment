function [L1 E1 k] = NLowmcpDCT(Y,Omega,opts)
%% DCT
%%
if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'rho');         rho   = opts.rho;            end
if isfield(opts, 'alpha');       alpha = opts.alpha;            end
if isfield(opts, 'beta');        beta = opts.beta;            end
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'itemax');      itemax = opts.itemax;        end
if isfield(opts, 'lambda');      lambda = opts.lambda;        end
if isfield(opts, 'q1');          q1 = opts.q1;        end
if isfield(opts, 'q2');          q2 = opts.q2;        end
if isfield(opts, 'lam');          lam = opts.lam;        end
if isfield(opts, 'a');          a = opts.a;        end
if isfield(opts, 'r1');          r1 = opts.r1;        end
if isfield(opts, 'r2');          r2 = opts.r2;        end
if isfield(opts, 'mu1');          mu1 = opts.mu1;        end
if isfield(opts, 'mu2');          mu2 = opts.mu2;        end
if isfield(opts, 'tr1');           tr1 = opts.tr1;        end
if isfield(opts, 'tr2');           tr2 = opts.tr2;        end

sizeD           = size(Y);

%% Initial 
L0  = zeros(sizeD);
E0  = zeros(sizeD);

for k = 1:itemax
   
    %% update L^{k+1}, F^{k+1}
  
%             lam = logspace(-5.5,1,itemax);
%      L1 = prox_N(L0 + (rho*(Y - L0 - E0).*Omega)/alpha,q1,1/alpha);
%      E1 = prox_Lq(E0 + (rho*(Y - L1 - E0).*Omega)/beta,q2,lambda/beta);
%      E1 = lpLSmatrix(E0 + (rho*(Y - L1 - E0).*Omega)/beta,q2,lambda/beta);

%        L1 = prox_Nscad(L0 + (rho*(Y - L0 - E0).*Omega)/alpha,lam,1/alpha,a);%
%        E1 = prox_scad(E0 + (rho*(Y - L1 - E0).*Omega)/beta,lam,lambda/beta,a);

%     L1 = prox_Nmcp(L0 + (rho*(Y - L0 - E0).*Omega)/alpha,lam,1/alpha,r1);%
%     E1 = prox_mcp(E0 + (rho*(Y - L1 - E0).*Omega)/beta,lam,lambda/beta,r1);
% %     
%          L1 = prox_Nfirm(L0 + (rho*(Y - L0 - E0).*Omega)/alpha,lam,1/alpha,mu1);%
%         E1 = prox_firm(E0 + (rho*(Y - L1 - E0).*Omega)/beta,lam,lambda/beta,mu2);
   
 %       L1 = prox_Nlog(L0 + (rho*(Y - L0 - E0).*Omega)/alpha,1/alpha,tr1);%
 %       E1 = prox_log(E0 + (rho*(Y - L1 - E0).*Omega)/beta,lambda/beta,tr2);
 
       L1 = prox_Nmcp(L0 + (rho*((Y - L0  - E0).*Omega))/alpha,lam,1/alpha,r1);%
      E1 = prox_mcp(E0 + (rho*((Y - L1).*Omega - E0))/beta,lam,lambda/beta,r2);

   %% stop criterion
   A = rho*(L1 - L0 + E1 - E0).*Omega - alpha*(L1 - L0);
   B = (rho - beta)*(E1 - E0);
   
%    Rel = (norm(A(:)) + norm(B(:)))/(1+norm(L1(:)) + norm(E1(:)));
   Obser = Y.*Omega;
   Rel = (norm(A(:)) + norm(B(:)))/(1+norm(Obser(:)) + norm(L1(:)) + norm(E1(:)));
   if Rel  <= tol
       break; 
   end
   
    %% update variable
   L0 = L1;
   E0 = E1;
end

end