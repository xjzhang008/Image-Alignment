function glog = LogG(x, Log)

% G(x) 文章3中非凸 向量的G值  第二项
%
% x     -    向量
%
% G log函数
%
glog = 0;
sizeX =length(x);
for i = 1: sizeX
    glog = glog + log(1+abs(x(i))/Log);
end
end