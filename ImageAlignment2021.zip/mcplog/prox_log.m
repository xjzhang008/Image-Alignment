function res=prox_log(x,lambda,theta)
        z = abs(x) - theta;
		v = z.*z - 4.0*(lambda - abs(x)*theta);
        
        
        sqrtv = sqrt(v);
		xtemp1 = max(0,0.5*(z + sqrtv));
		xtemp2 = max(0,0.5*(z - sqrtv));

		ytemp0 = 0.5*x.*x;
		ytemp1= 0.5*(xtemp1 - abs(x)).*(xtemp1 - abs(x)) + lambda*log(1.0 + xtemp1/theta);
		ytemp2 = 0.5*(xtemp2 - abs(x)).*(xtemp2 - abs(x)) + lambda*log(1.0 + xtemp2/theta);
        
        sel1=(ytemp1<ytemp2).*(ytemp1<ytemp0);
        sel2=(ytemp2<ytemp1).*(ytemp2<ytemp0);
        
        xtemp=sel1.*xtemp1+sel2.*xtemp2;
        
        res=sign(x).*(v>0).*xtemp;
end