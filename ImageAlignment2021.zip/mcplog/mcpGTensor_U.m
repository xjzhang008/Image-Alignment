function tnn = mcpGTensor_U(UU, T, c, eta)

% G(Y) 文章3中非凸张量 第一项
%
% Y     -    n1*n2*n3 tensor
%
% X     -    数
%

% 

[n1,n2,n3] = size(T);
O = tenmat(T,[3]); %square norm
SS = O.data;
T = UU'*SS;
T = tensor(tenmat(T, O.rdims, O.cdims, O.tsize));
Y = T.data;


tnn=0;

for i = 1 : n3
    [U,S,V] = svd(Y(:,:,i),'econ');
  x =S(:);
  sizeX =size(x);
gmcp = c^2*eta/2*ones(sizeX);  
i1 = find(abs(x)<=eta*c);
gmcp(i1) = c*abs(x(i1))-1/(2*eta)*x(i1).*x(i1);
tnn = tnn + sum(gmcp);
end

end