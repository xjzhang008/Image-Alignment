function glq = LqG(x, q)

% G(x) 文章3中非凸 向量的G值  第二项
%
% x     -    向量
%
% G lq函数
%
glq = 0;
sizeX =length(x);
for i = 1: sizeX
    glq = glq + abs(x(i))^q;
end
end