function tnn = mcpGTensor(Y, c, eta)

% G(Y) 文章3中非凸张量 第一项
%
% Y     -    n1*n2*n3 tensor
%
% X     -    数
%

% 

[n1,n2,n3] = size(Y);
Y = dct(Y,[],3);

tnn=0;

for i = 1 : n3
    [U,S,V] = svd(Y(:,:,i),'econ');
  x =S(:);
  sizeX =size(x);
gmcp = c^2*eta/2*ones(sizeX);  
i1 = find(abs(x)<=eta*c);
gmcp(i1) = c*abs(x(i1))-1/(2*eta)*x(i1).*x(i1);
tnn = tnn + sum(gmcp);
end

end