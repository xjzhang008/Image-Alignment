function gmcp = mcpG(x, c, eta)

% G(x) 文章3中非凸 向量的G值  第二项
%
% x     -    向量
%
% G mcp函数
%
sizeX =size(x);
gmcp = c^2*eta/2*ones(sizeX);   
i1 = find(abs(x)<=eta*c);
gmcp(i1) = c*abs(x(i1))-1/(2*eta)*x(i1).*x(i1);
gmcp = sum(gmcp);
end

