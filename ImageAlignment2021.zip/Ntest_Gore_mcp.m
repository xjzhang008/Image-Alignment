

% clear
clc ;
clear all;
close all ;

% addpath
addpath mymain ; 
addpath myin ;
addpath mybase ;
addpath mcplog ;
addpath tensor_toolbox;
%% define images' path

currentPath = cd;
%currentPath1 = currentPath(1:end-9);

userName = 'Al_Gore' ;

% output path
destRoot = fullfile(currentPath,'results') ;
destDir = fullfile(destRoot,userName) ;
if ~exist(destDir,'dir')
    mkdir(destRoot,userName) ;
end



%% define parameters

% display flag
para.DISPLAY = 0 ;

% save flag
para.saveStart = 1 ;
para.saveEnd = 1 ;
para.saveIntermedia = 0 ;


% for face images
para.canonicalImageSize =[ 80  60 ];
para.canonicalCoords = [ 5  55 ; ...
                        32 32  ];
co = para.canonicalCoords;                            
% parametric tranformation model
para.transformType = 'AFFINE'; 
% one of 'TRANSLATION', 'EUCLIDEAN', 'SIMILARITY', 'AFFINE','HOMOGRAPHY'

para.numScales = 1 ; % if numScales > 1, we use multiscales

% main loop
para.stoppingDelta = 1e-2; % stopping condition of main loop
para.maxIter = 200; % maximum iteration number of main loops

% inner loop
para.inner_tol = 5e-2;
para.inner_maxIter = 300 ;
para.continuationFlag = 1 ;
%para.mu = 5e-3 ;
para.optmet = 'MCP';


para.lambdac = 7;%
para.rho = 40;
%% mcp参数
para.lam = 0.5;
para.rg = 100;
para.Log = 3;%
para.gamma = 0.001; 

    % input path
imagePath = fullfile(currentPath,'data') ;
pointPath = fullfile(currentPath,'data') ; % path to files containing initial feature coordinates
% get initial transformation
transformationInit = 'SIMILARITY'; 
%ImagefileNames = [userName '_Theta' num2str(thetaMax) 'Ts' num2str(TransMax) noisePara.type 'Ex' num2str(Ex)];% 'salt' 'occlusion' 
[fileNames, transformations, numImages] = get_training_images( imagePath, pointPath, userName, co, transformationInit);
%%  main loop: do robust batch image alignment
tic
[Do, A, E, xi] = Ntnn_main_U1_other(fileNames, transformations, numImages, para, destDir);
toc
 
layout.xI = 10 ;
layout.yI = 14 ;  
layout.gap = 0 ;
layout.gap2 = 0 ;
NTNN_plot(destDir, numImages, para.canonicalImageSize, layout);  