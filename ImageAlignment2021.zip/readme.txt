This code includes the detailed implementation of Robust low transformed multi-rank tensor methods for image alignment.

Ref:
'' D. Qiu, M. Bai, M. K. Ng, and X. Zhang. Robust low transformed multi-rank tensor methods for image alignment. Journal of Scientific Computing, 87(1):24, 2021.‘’


You can directly running 'Ntest_Gore_mcp.m' for AI_Gore data.
