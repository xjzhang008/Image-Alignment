function [Do, A, E, xi, numIterOuter, numIterInner] = Ntnn_main_U1(fileNames, transformations, numImages, para, destDir)



%% read and store full images
fixGammaType = 1 ;% =1时下�?..8-17都无�?

if ~fixGammaType
    if exist(fullfile(rootPath, userName, 'gamma_is_ntsc'), 'file')
        gammaType = 'ntsc' ;
    elseif exist(fullfile(rootPath, userName, 'gamma_is_srgb'), 'file')
        gammaType = 'srgb' ;
    elseif exist(fullfile(rootPath, userName, 'gamma_is_linear'), 'file')
        gammaType = 'linear' ;
    else
        error('Gamma type not specified for training database!  Please create a file of the form gamma_is_*') ;
    end
else
    gammaType = 'linear' ;
end

sigma0 = 2/5 ;
sigmaS = 1 ;

deGammaTraining = true ;% logical 1

I0 = cell(para.numScales,numImages) ; %cell矩阵；numScales=1�?1*numImages
I0x = cell(para.numScales,numImages) ; 
I0y = cell(para.numScales,numImages) ;

for fileIndex = 1 : numImages
    
    currentImage = double(imread(fileNames{fileIndex}));
    if size(currentImage,3) > 1,   currentImage = currentImage(:,:,2);            end
    %gamma_decompress：把其他空间（Srgb \ntsc）空间图像变�? linear�?.  uint8 to double.  uint8�?8位无符号整型
    if deGammaTraining,      currentImage = gamma_decompress(currentImage, gammaType); end
% gauss_pyramid对图像滤�? 去噪
    currentImagePyramid = gauss_pyramid( currentImage, para.numScales,...
        sqrt(det(transformations{fileIndex}(1:2,1:2)))*sigma0, sigmaS );%没看懂参数取值来�?
        
    for scaleIndex = para.numScales:-1:1 %para.numScales=1 这个循环显得多余
        I0{scaleIndex,fileIndex} = currentImagePyramid{scaleIndex};%cell
        I0_smooth = I0{scaleIndex,fileIndex};
        I0x{scaleIndex,fileIndex} = imfilter( I0_smooth, -fspecial('sobel')' / 8 );%imfilter对任意类型数组或多维图像进行滤波 见https://blog.csdn.net/u010740725/article/details/51557202
        I0y{scaleIndex,fileIndex} = imfilter( I0_smooth,  -fspecial('sobel')   / 8 );%sobel 边缘�?测算�? https://blog.csdn.net/sw3300255/article/details/82501847
    end   
end

%% get the initial input images in canonical frame
% 这一部分主要输出D�?'xi_initial分别表示D圈tau tau
%currentImage1 = double(imread(fileNames{1}));
%imgSize0 = size(currentImage1);
imgSize = para.canonicalImageSize ; 
  gamma = para.gamma;  
gap1 = 0;
gap2 = 0;   
xi_initial22 = cell(1,numImages) ;%文章中tau 每个cell 1*8
xi_initial = cell(1,numImages) ;%文章中tau 每个cell 1*8
parfor i = 1 : numImages
    if size(transformations{i},1) < 3
        transformations{i} = [transformations{i} ; 0 0 1] ;%transformations中cell变成3�?
    end
    % xi_initial：[\tau_1,...,\tau_n];
    xi_initial22{i} = projective_matrix_to_parameters(para.transformType,transformations{i});  %把矩阵transformations中的元素分别赋给xi_initial
end
for i = 1 : numImages
    xi_initial{i} = xi_initial22{i};
end
D = zeros(imgSize(1)*imgSize(2), numImages); %文章中雅克比矩阵 40000*16

for fileIndex = 1 : numImages
    % transformed image
    %fliptform把原本括号内的结构体 希望执行变换（tformfwd tforminv）的类型互换�? 但data没变(两次命令后就又还原了)  http://training.eeworld.com.cn/video/16532；http://www.ece.northwestern.edu/local-apps/matlabhelp/toolbox/images/fliptform.html
    Tfm = fliptform(maketform('projective',transformations{fileIndex}'));%maketform生成的结构体中包含希望执行变换的类型、变化矩阵及其�?�矩�?
    %maketform：http://www.ece.northwestern.edu/local-apps/matlabhelp/toolbox/images/maketform.html；http://blog.sina.com.cn/s/blog_6163bdeb0102du23.html
    TTfm = imtransform(I0{1,fileIndex}, Tfm,'bicubic','XData',[1 imgSize(2)],'YData',[1 imgSize(1)],'Size',imgSize);
    %TTfm = imtransform(I0{1,fileIndex}, Tfm,'bicubic','XData',[gap2+1 gap2+imgSize(2)],'YData',[gap1+1 gap1+imgSize(1)],'Size',imgSize);
    I   = vec(TTfm);
    %imtransform()函数用于完成�?般的二维空间变换�?'bicubic'三次插�?? https://ww2.mathworks.cn/help/images/ref/imtransform.html
    %https://www.jianshu.com/p/7f534165f734; https://blog.csdn.net/wenhao_ir/article/details/51405187;
    y   = I; 
    y = y / norm(y) ; 
    D(:,fileIndex) = y ;  
end

if para.saveStart
    % save(fullfile(destDir, 'or10.mat'),'D') ;
    save(fullfile(destDir, 'original-sralt.mat'),'D','xi_initial') ;
end

%% start the main loop
frOrig = cell(1,numImages) ;
T_in = cell(1,numImages) ;
%T_in其中�?个cell3*3矩阵 =[4.94,0.5465,187.944;0.22,4.426375,97.797;0,0,1]
T_ds = [ 0.5,   0, -0.5; ...
         0,   0.5, -0.5   ];
T_ds_hom = [ T_ds; [ 0 0 1 ]];

numIterOuter = 0 ; 
numIterInner = 0 ;
yy = [imgSize(1) imgSize(2) numImages];LL = zeros(yy); EE =zeros(yy); 
tic % time counting start
for scaleIndex = para.numScales:-1:1 
    
    iterNum = 0 ;  % iteration number of outer loop in each scale
    converged = 0 ;
    prevObj = inf ; % previous objective function value
    
    imgSize = para.canonicalImageSize / 2^(scaleIndex-1) ;   %200*200 
    xi = cell(1,numImages) ;
    
    for fileIndex = 1 : numImages
             
        if scaleIndex == para.numScales
            T_in{fileIndex} = T_ds_hom^(scaleIndex-1)*transformations{fileIndex}*inv(T_ds_hom^(scaleIndex-1)) ;%T_ds_hom^(scaleIndex-1)单位矩阵 因此这个结果是transformations{fileIndex}
        else
            T_in{fileIndex} = inv(T_ds_hom)*T_in{fileIndex}*T_ds_hom ;
        end
        
        % for display purposes
        if para.DISPLAY > 0 % =0
            fr = [1 1          imgSize(2) imgSize(2) 1; ...
                  1 imgSize(1) imgSize(1) 1          1; ...
                  1 1          1          1          1 ];
            % 
            frOrig{fileIndex} = T_in{fileIndex} * fr;
        end
        
    end
    
    while ~converged

        iterNum = iterNum + 1 ;
        numIterOuter = numIterOuter + 1 ;
        
        D= zeros(imgSize(1)*imgSize(2), numImages);
        J = cell(1,numImages) ;
        disp(['Scale ' num2str(scaleIndex) '  Iter ' num2str(iterNum)]) ;%Scale�?直等�?1
        
        parfor fileIndex = 1 : numImages

            % transformed image and derivatives with respect to affine
            Tfm = fliptform(maketform('projective',T_in{fileIndex}'));%Tfm数据包括T_in{fileIndex}' 与其�?
%maketform 使用maketform函数可以创建TFORM结构体，参数为希望执行变换的类型和变换矩阵�?? fliptform 转换TFORM结构的forward �? inverse transformations 
%imtransform函数执行变换，参数为要变换的图像和TFORM结构体，函数将返回变换后的图像�??
%Size 输出图像大小
            I   = vec(imtransform(I0{scaleIndex,fileIndex}, Tfm,'bicubic','XData',[gap2+1 gap2+imgSize(2)],'YData',[gap1+1 gap1+imgSize(1)],'Size',imgSize));
            Iu  = vec(imtransform(I0x{scaleIndex,fileIndex},Tfm,'bicubic','XData',[gap2+1 gap2+imgSize(2)],'YData',[gap1+1 gap1+imgSize(1)],'Size',imgSize));
            Iv  = vec(imtransform(I0y{scaleIndex,fileIndex},Tfm,'bicubic','XData',[gap2+1 gap2+imgSize(2)],'YData',[gap1+1 gap1+imgSize(1)],'Size',imgSize));
            y   = I; %vec(I);

            Iu = (1/norm(y))*Iu - ( (y'*Iu)/(norm(y))^3 )*y ;%40000*1
            Iv = (1/norm(y))*Iv - ( (y'*Iv)/(norm(y))^3 )*y ;%40000*1

            y = y / norm(y) ; % normalize
            D(:,fileIndex) = y ;%40000*16

            % transformation matrix to parameters;
            xi{fileIndex} = projective_matrix_to_parameters(para.transformType,T_in{fileIndex}) ;
            J{fileIndex} = image_Jaco(Iu, Iv, imgSize, para.transformType, xi{fileIndex});%40000*8
        end
        
        lambda = para.lambdac/sqrt(numImages*max(imgSize(1),imgSize(2))) ;
        r1 = para.rg/(para.rho+1e-3); Log = para.Log;
        % SRALT inner loop
        % -----------------------------------------------------------------
        % -----------------------------------------------------------------
        % using QR to orthogonalize the Jacobian matrix
%         parfor fileIndex = 1 : numImages
%             [Q{fileIndex}, R{fileIndex}] = qr(J{fileIndex},0) ;%Q为cell 1*16个，每个cell:Q:40000*8 R:8*8;m > n; 且Q的伪逆就�? Q的转�?
%         end
        
        D_tensor = Fold(D',[imgSize(1) imgSize(2) numImages],3);    
      
        if strcmp(para.optmet,'MCP')
           if iterNum == 1
            [Ld, Sd, T1d, delta_xid, numIterInnerEachd, kkd, reld] = Ntnn_inner_mcp1(gamma, D_tensor, J, lambda, para.rho, para.lam,r1,Log, para.inner_tol, para.inner_maxIter ,LL, EE);
             O = Unfold(Ld,[imgSize(1) imgSize(2) numImages],3);
             [U Dcc Vcc] = svd(O,'econ');
            
            end
             [L, S, T1, delta_xi, numIterInnerEach, kk, rel] = Ntnn_inner_mcp_U1(gamma, U, D_tensor, J, lambda, para.rho, para.lam,r1,Log, para.inner_tol, para.inner_maxIter ,LL, EE);
             
        end
       
      %L, E: 200*200*16  delta_xi: cell 1*16 每个cell�?3*3

      LL = L; EE = S;
        
         kk
        rel
%         parfor fileIndex = 1 : numImages
%             delta_xi{fileIndex} = inv(R{fileIndex})*delta_xi{fileIndex};
%         end
        A = Unfold(L,[imgSize(1) imgSize(2) numImages],3)';
        E = Unfold(S,[imgSize(1) imgSize(2) numImages],3)';
        numIterInner = numIterInner + numIterInnerEach ;
        RT = D_tensor + T1- L - S;  %RT = Unfold(RT,size(RT),3);
%          vvv = size(delta_xi{1});
%         datetao =zeros(vvv);dff =0;
%         for jk = 1:numImages
%             datetao= delta_xi{jk};
%             dff = dff+ norm(datetao(:))^2;
%         end
        %curObj = mcpGTensor_U(U, L, para.lam, r1)+ lambda*mcpG(S(:), para.lam, r2)+para.rho/2*norm(RT(:))^2+gamma/2*dff;
        %curObj = mcpGTensor_U(U, L, para.lam, r1)+ lambda*mcpG(S(:), para.lam, r2)+para.rho/2*norm(RT(:))^2;
        curObj = mcpGTensor_U(U, L, para.lam, r1)+ lambda*LogG(S(:),Log)+para.rho/2*norm(RT(:))^2;
        disp(['previous objective function: ' num2str(prevObj) ]);
        disp([' current objective function: ' num2str(curObj) ]);

        % step in paramters
        parfor i = 1 : numImages
            xi{i} = xi{i} + delta_xi{i};
            T_in{i} = parameters_to_projective_matrix(para.transformType,xi{i});
        end

        if para.DISPLAY > 0
            parfor i = 1 : numImages
                figure(1); clf ;
                imshow(I0{scaleIndex,i},[],'Border','tight');%,'Border','tight'显示图像时去除灰色边�? http://cache.baiducontent.com/c?m=9f65cb4a8c8507ed19fa950d100b92235c4380146d8b804b2281d25f93130a1c187bbbec7b7e5b07d1c77e6503ad541ef7f533733d0221b68cc8ff109be4cc3c6ad567627f47d900488e5cb8cb37759c60c60da9b81996adf04384afa2958401098c44050b97f0fa4d0164953cb64a62b3&p=936fc64ad4934eac59eac022110d8c&newp=8b2a975690934eac59ea87355407cd231610db2151d6d7136b82c825d7331b001c3bbfb423281100d3c07e6700a44959e0f33370350923a3dda5c91d9fb4c574799b61&user=baidu&fm=sc&query=imshow+Border%27%2C%27tight%27%29matlab&qid=9fafea5e00022689&p1=7
                hold on;
                
                Tfm = fliptform(maketform('projective',inv(T_in{i}')));
                curFrame = tformfwd(fr(1:2,:)', Tfm )';%https://stackoverflow.com/questions/1534317/tformfwd-and-tforminv-whats-the-difference
                plot( frOrig{i}(1,:),   frOrig{i}(2,:),   'g-', 'LineWidth', 2 );
                plot( curFrame(1,:), curFrame(2,:), 'r-', 'LineWidth', 2 );
%                 hold off;
%                 print('-f1', '-dbmp', fullfile(destDir, num2str(i))) ;%图片保存“批处理�?
               
            end
        end
         %if ( (curObj < 3) || iterNum >= para.maxIter )
        %if ( iterNum >= para.maxIter )
        if ( (prevObj - curObj < para.stoppingDelta) || iterNum >= para.maxIter )
           
            converged = 1;
            if ( prevObj - curObj >= para.stoppingDelta )
                disp('Maximum iterations reached') ;
            end
        else
            prevObj = curObj;
        end
        
    end
end

disp(['total number of iterations: ' num2str(numIterInner) ]);
disp(['number of outer loop: ' num2str(numIterOuter) ]);
timeConsumed = toc;

%% save the alignment results
Do = [] ; 
parfor fileIndex = 1 : numImages
    Tfm = fliptform(maketform('projective',T_in{fileIndex}'));   
    I   = vec(imtransform(I0{1,fileIndex}, Tfm,'bicubic','XData',[gap2+1 gap2+imgSize(2)],'YData',[gap1+1 gap1+imgSize(1)],'Size',imgSize));
    y   = I; 
    y = y / norm(y) ; % normalize
    Do = [Do y] ;
end

if para.saveEnd
    save(fullfile(destDir, 'final-sralt.mat'),'Do','A','E','xi') ;
    outputFileName = fullfile(destDir, 'final-sralt_results.txt'); 
    fid = fopen(outputFileName,'a') ;
    fprintf(fid, '%s\n', [' total number of iterations: ' num2str(numIterInner) ]) ;
    fprintf(fid, '%s\n', [' number of outer loop ' num2str(numIterOuter) ]) ;
    fprintf(fid, '%s\n', [' consumed time: ' num2str(timeConsumed)]) ;
    fprintf(fid, '%s\n', [' the parameters :']) ;
    fprintf(fid, '%s\n', [' transformType ' para.transformType ]) ;
    fprintf(fid, '%s\n', [' lambda ' num2str(para.lambdac) ' times sqrt(m)']) ;
    fprintf(fid, '%s\n', [' stoppingDelta of outer loop ' num2str(para.stoppingDelta) ]) ;
    fprintf(fid, '%s\n', [' stoppingDelta of inner loop ' num2str(para.inner_tol)]) ;
    if strcmp(para.optmet,'MCP')
        fprintf(fid, '%s\n', [' optimization in inner loop is using ADMM algorithm']) ;
    else 
        fprintf(fid, '%s\n', [' optimization in inner loop is using LADM algorithm']) ;
    end
    fclose(fid);
end
close all;
