%% 不成整体 单独算 
function [L1, S1,T1, dt_tau_row, iter, k, Rel] = Ntnn_inner_mcp_U1(gamma, U, D, J, lambda, rho,lam,r1,Log, tol, maxIter ,LL,EE)
sizeD   = size(D);
[n1, n2, n3] = size(D); 
alg1 = 1e-3; alg2 = 1e-3; alg3 = 1e-2; 
L0 = LL;
S0 = EE;
T0 = zeros(sizeD);
dt_tau_row = cell(1,n3);
dt_tau_row0 = cell(1,n3);
dt_dual_matrix = zeros(n1*n2, n3);
[mm1 mm2] = size(J{1});
II = eye(mm2);
for i = 1: n3
    dt_tau_row0{i} = zeros(mm2,1);
end
iter = 0;
for k = 1:maxIter
   
 %% update L
   L1 =  prox_NmcpU(U, (rho*(T0 + D - S0)+alg1*L0)/(rho+alg1),lam,1/(rho+alg1),r1);%
 %% update S
    S1 = prox_log((rho*(T0 + D - L1) + alg2*S0)/(rho+alg2),lambda/(rho+alg2),Log); 
 %% update T
    A = L1+S1-D; 
    T_wave3 = Unfold(A,size(A),3)'; 
    for i = 1 : n3
        dt_tau_row{i} =  inv(J{i}'*J{i} + (gamma+alg3)/rho*II)*(J{i}'*T_wave3(:,i)+ alg3/rho*dt_tau_row0{i});%J的转置是其伪逆  8*1 文章中dt_dual的第i列 这个结果是对应文章式子（24）所得矩阵的第i列
        dt_dual_matrix(:, i) = J{i}*dt_tau_row{i} ;%对应约束中fold 及转置之前 连加之后得到的矩阵
     end  
    T1 = Fold(dt_dual_matrix',[n1 n2 n3],3);

%% stop criterion
if k >= 5
AE = rho*(S1 - S0)+ alg1*(L0 - L1) + rho*(T0- T1);
BE = rho*(T0- T1) - alg2* (S1-S0);
sv = size(dt_tau_row{1}); an = zeros(sv);bn = zeros(sv);
vb=0; %vb1 = 0;
for jh =1:n3
    bn = dt_tau_row{i};
    an = dt_tau_row0{i};
    vb = vb+ norm(an-bn)^2;
   % vb1 = vb1 + norm(bn)^2;
end
% CE = alg3*vb;

Rel = (norm(AE(:)) + norm(BE(:)) + alg3*sqrt(vb))/(1 + norm(D(:)) + norm(L1(:)) + norm(S1(:)) );%+  sqrt(vb1)

    if Rel <= tol
       break;
   end   
end

 %% update variable
 L0 = L1;
 S0 = S1;
 T0 = T1;
 dt_tau_row0 = dt_tau_row;
 iter = iter+1;
end



%% fold当成整体
% function [L1, S1, dt_tau_row, iter, k, Rel] = Ntnn_inner_mcp(D, J, lambda, rho,lam,r1,r2, tol, maxIter ,LL,EE)
% sizeD   = size(D);
% [n1, n2, n3] = size(D); 
% 
% L0 = LL;
% S0 = EE;
% T0 = zeros(sizeD);
% dt_tau_row = cell(1,n3);
% %dt_dual_matrix = zeros(n1*n2, n3);
% 
% iter = 0;
% for k = 1:maxIter
%    
%  %% update L
%    L1 =  prox_Nmcp(T0 + D - S0,lam,1/rho,r1);%
%  %% update S
%     S1 = prox_mcp(T0 + D - L1,lam,lambda/rho,r2); 
%  %% update T
%     T1 = L1 + S1 - D;  
% %% stop criterion 
%   A = rho*(L1 - L0 + S1 - S0) - (L1 - L0);
% %    B = (rho -0)*(S1 - S0);
% % Rel = (norm(A(:)) + norm(B(:)))/(1+norm(Obser(:)) + norm(L1(:)) + norm(E1(:)));
% %A = D+T1-L1-S1;
% Rel = 1;  
%  %% update variable
%  L0 = L1;
%  S0 = S1;
%  T0 = T1;
%  iter = iter+1;
% end
% T_wave3 = Unfold(T1,size(T1),3)';
%  for i = 1 : n3
%         dt_tau_row{i} =  J{i}'*T_wave3(:,i) ;%J的转置是其伪逆  8*1 文章中dt_dual的第i列 这个结果是对应文章式子（24）所得矩阵的第i列       
%  end  
