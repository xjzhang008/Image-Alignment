function [X] = Fold(X, dim, i)
% X想要折叠的矩阵 dim想要折叠成的维度 i第几个维度折叠
dim = circshift(dim, [1-i, 1-i]);
X = shiftdim(reshape(X, dim), length(dim)+1-i);