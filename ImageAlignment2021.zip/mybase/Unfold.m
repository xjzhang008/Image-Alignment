
function [X] = Unfold( X, dim, i )
%dim为张量维度 i为想要展开的第几维
X = reshape(shiftdim(X,i-1), dim(i), []);