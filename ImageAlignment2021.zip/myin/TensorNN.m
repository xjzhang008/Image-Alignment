function tnn = TensorNN(Y)

% ||Y||TNN
%
% Y     -    n1*n2*n3 tensor
%
% X     -    数
%

% 

[n1,n2,n3] = size(Y);
Y = dct(Y,[],3);

tnn = 0;

for i = 1 : n3
    [U,S,V] = svd(Y(:,:,i),'econ');
  
    tnn = tnn + sum(S(:));

end


